# Copyright (c) 2026, Frappe Technologies Pvt. Ltd. and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document


class CRMWhatsAppMessage(Document):
	def after_insert(self):
		"""Publish realtime event after message is created."""
		frappe.publish_realtime(
			"whatsapp_message_sent",
			{
				"message_id": self.message_id,
				"reference_doctype": self.reference_doctype,
				"reference_docname": self.reference_docname,
				"status": self.status,
			},
		)
