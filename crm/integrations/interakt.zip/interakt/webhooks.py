import frappe
from frappe import _


@frappe.whitelist(allow_guest=True)
def handle_webhook(**kwargs):
	"""
	Handle incoming webhooks from Interakt.
	This endpoint receives delivery status updates and incoming messages.
	
	Webhook URL: https://yoursite.com/api/method/crm.integrations.interakt.webhooks.handle_webhook
	"""
	try:
		args = frappe._dict(kwargs)
		
		# Log the webhook for debugging
		frappe.log_error(
			title="Interakt Webhook Received",
			message=frappe.as_json(args, indent=2),
		)

		# Determine webhook type based on payload
		# Interakt sends different webhook types for different events
		
		# Message status update webhook
		if args.get("id"):  # Message ID present
			update_message_status(args)
		
		# Incoming message webhook
		elif args.get("type") == "message" and args.get("direction") == "incoming":
			handle_incoming_message(args)
		
		return {"success": True, "message": "Webhook processed"}
		
	except Exception as e:
		frappe.log_error(
			title="Interakt Webhook Error",
			message=f"Error processing webhook: {str(e)}\nPayload: {frappe.as_json(kwargs)}",
		)
		return {"success": False, "error": str(e)}


def update_message_status(args):
	"""
	Update message status based on webhook data.
	
	Expected webhook payload for status updates:
	{
		"id": "message_id",
		"status": "sent" | "delivered" | "read" | "failed",
		"timestamp": "ISO-8601 timestamp"
	}
	"""
	message_id = args.get("id")
	status = args.get("status", "").lower()
	timestamp = args.get("timestamp")
	
	if not message_id:
		return
	
	# Find the message log
	message_log = frappe.db.get_value(
		"CRM WhatsApp Message",
		{"message_id": message_id},
		"name",
	)
	
	if not message_log:
		frappe.log_error(
			title="WhatsApp Message Not Found",
			message=f"Message ID: {message_id} not found in CRM WhatsApp Message",
		)
		return
	
	# Map Interakt status to our status
	status_map = {
		"sent": "Sent",
		"delivered": "Delivered",
		"read": "Read",
		"failed": "Failed",
	}
	
	mapped_status = status_map.get(status, "Sent")
	
	# Update the message log
	doc = frappe.get_doc("CRM WhatsApp Message", message_log)
	doc.status = mapped_status
	
	# Update timestamps
	if status == "sent" and not doc.sent_at:
		doc.sent_at = timestamp or frappe.utils.now()
	elif status == "delivered" and not doc.delivered_at:
		doc.delivered_at = timestamp or frappe.utils.now()
	elif status == "read" and not doc.read_at:
		doc.read_at = timestamp or frappe.utils.now()
	elif status == "failed":
		doc.error_message = args.get("error_message") or "Message delivery failed"
	
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	
	# Publish realtime update
	frappe.publish_realtime(
		"whatsapp_message_status_update",
		{
			"message_id": message_id,
			"status": mapped_status,
			"reference_doctype": doc.reference_doctype,
			"reference_docname": doc.reference_docname,
		},
	)


def handle_incoming_message(args):
	"""
	Handle incoming WhatsApp messages.
	Note: This is for future implementation if Interakt supports incoming messages.
	
	Expected webhook payload:
	{
		"type": "message",
		"direction": "incoming",
		"from": "phone_number",
		"message": "message_content",
		"timestamp": "ISO-8601 timestamp"
	}
	"""
	# For Phase 1, we're only supporting outbound messages
	# This is a placeholder for future implementation
	frappe.log_error(
		title="Incoming WhatsApp Message (Not Implemented)",
		message=f"Received incoming message: {frappe.as_json(args)}",
	)
	pass
